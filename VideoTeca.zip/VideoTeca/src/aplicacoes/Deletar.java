package aplicacoes;

import java.util.List;

import com.db4o.ObjectContainer;
import com.db4o.query.Query;

import aplicacoes.Deletar;

import modelo.Genero;
import modelo.Video;


public class Deletar {
	protected ObjectContainer manager;
	
	public Deletar() {
		manager = Util.conectarBanco();
		apagar();
		Util.desconectar();
		
		System.out.println("\n\n aviso: feche sempre o plugin OME antes de executar aplica��o");
	}
	
	public void apagar() {
		Query q = manager.query();
		q.constrain(Video.class);
		q.descend("titulo").constrain("VF10");
		List<Video> resultados = q.execute();
		
		if (resultados.size() > 0) {
			Video v = resultados.get(0);
			Genero g = v.getGenero();
			manager.delete(v);
			manager.delete(g);
			manager.commit();
			System.out.println("Apagou VF10");
		} else
			System.out.println("Filme nao existe");
	}
	
	
	public static void main(String[] args) {
		new Deletar();
	}
}
