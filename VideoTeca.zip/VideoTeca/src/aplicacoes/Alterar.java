package aplicacoes;

import java.util.List;

import com.db4o.ObjectContainer;
import com.db4o.query.Query;

import aplicacoes.Alterar;

import modelo.Video;

public class Alterar {
	protected ObjectContainer manager;

	public Alterar(){
		manager = Util.conectarBanco();
		atualizar();
		Util.desconectar();

		System.out.println("\n\n aviso: feche sempre o plugin OME antes de executar aplica��o");
	}
	
	public void atualizar() {
		Query q = manager.query();
		q.constrain(Video.class);
		q.descend("titulo").constrain("VF10");
		List<Video> resultados = q.execute();
		
		if(resultados.size() > 0) {
			Video v = resultados.get(0);
			v.setClassificacao(3.0);
			
			manager.store(v);
			manager.commit();	
			System.out.println("alterou classificacao.");
		}else
			System.out.println("nao achei filme.");
			
	}
	
	public static void main(String[] args) {
		new Alterar();
	}

}
