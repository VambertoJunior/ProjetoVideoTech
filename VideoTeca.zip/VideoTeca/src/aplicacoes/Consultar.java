package aplicacoes;

import java.util.List;

import com.db4o.ObjectContainer;
import com.db4o.query.Candidate;
import com.db4o.query.Evaluation;
import com.db4o.query.Query;

import aplicacoes.Consultar;

import modelo.Genero;
import modelo.Video;

public class Consultar {
	protected ObjectContainer manager;

	public Consultar(){
		manager = Util.conectarBanco();
		consultar();
		Util.desconectar();
		
		System.out.println("\n\n aviso: feche sempre o plugin OME antes de executar aplica��o");
	}

	public void consultar(){
		System.out.println("/n---mostrar o ordem de alfabeto dos filmes");
		Query q1 = manager.query();
		q1.constrain(Video.class);  
		q1.descend("classificacao").orderAscending();
		List<Video> video = q1.execute();
		for(Video v: video)
			System.out.println(v);
		
		System.out.println("/n---mostrar o ordem de alfabeto dos generos");
		Query q2 = manager.query();
		q2.constrain(Video.class);  
		q2.descend("genero").descend("nome").orderAscending();
		List<Video> video1 = q2.execute();
		for(Video v: video1)
			System.out.println(v);
	}
	
	public static void main(String[] args) {
		new Consultar();
	}
	
	class Filtro implements Evaluation {
		public void evaluate(Candidate candidate) {
			Genero g = (Genero) candidate.getObject();
			
			if(g.getListaDeVideo().size()==1) 
				candidate.include(true); 	//incluir objeto no resultado da consulta
			else		
				candidate.include(false);	//excluir objeto do resultado da consulta
		}	
	}
}