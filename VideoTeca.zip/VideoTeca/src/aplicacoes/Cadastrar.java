package aplicacoes;

import com.db4o.ObjectContainer;

import modelo.Genero;
import modelo.Video;

public class Cadastrar {
	protected ObjectContainer manager;
	
	public Cadastrar(){
		manager = Util.conectarBanco();
		cadastrar();
		Util.desconectar();
		
		System.out.println("fim da aplicacao");
	}

	public void cadastrar(){
		System.out.println("cadastrando...");
		
		Genero acao = new Genero("Acao");
		Genero comedia = new Genero("Comedia");
		Genero drama = new Genero("Drama");
		Genero terror = new Genero("Terror");
		Genero guerra = new Genero("Guerra");
		manager.store(acao);
		manager.commit();
		
		manager.store(comedia);
		manager.commit();
		
		manager.store(drama);
		manager.commit();
		
		manager.store(terror);
		manager.commit();
		
		manager.store(guerra);
		manager.commit();
		
		
		Video video1 = new Video(1, "VF10", "https://netflix.com/video1", 4.5, acao);
		Video video2 = new Video(2, "Mr Bean", "https://netflix.com/video2", 4.8, comedia);
		Video video3 = new Video(3, "O Acordo", "https://primevideo.com/video3", 3.1, drama);
		Video video4 = new Video(4, "Megan", "https://primevideo.com/video4", 4.0, terror);
		Video video5 = new Video(5, "Narvik", "https://www.com/video5", 4.1, guerra);
		manager.store(video1);
		manager.commit();
		
		manager.store(video2);
		manager.commit();
		
		manager.store(video3);
		manager.commit();
		
		manager.store(video4);
		manager.commit();
		
		manager.store(video5);
		manager.commit();
	}
	
	public static void main(String[] args) {
		new Cadastrar();
	}
}
