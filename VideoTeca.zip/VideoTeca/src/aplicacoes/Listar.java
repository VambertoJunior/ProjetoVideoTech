package aplicacoes;

import java.util.List;

import com.db4o.ObjectContainer;
import com.db4o.query.Query;

import aplicacoes.Listar;

import modelo.Genero;
import modelo.Video;

public class Listar {
	protected ObjectContainer manager;

	public Listar(){
		manager = Util.conectarBanco();
		listaGenero();
		listaVideo();
		Util.desconectar();
		
		System.out.println("\n\n aviso: feche sempre o plugin OME antes de executar aplica��o");
	}
	 public void listaGenero() {
		 System.out.println("\n---Listagem das generos:");
		 
		 Query q = manager.query();
		 q.constrain(Genero.class);
		 List<Genero> resultados = q.execute();
		 for(Genero g: resultados)
			 System.out.println(g); 
	 }
	 
	 public void listaVideo() {
		 System.out.print("/n---Listagem dos videos");
		 
		 Query q = manager.query();
		 q.constrain(Video.class);
		 List<Video> resultados = q.execute();
		 for(Video v: resultados)
			 System.out.println(v); 
	 }
	 
	 public static void main(String[] args) {
			new Listar();
		}

}
