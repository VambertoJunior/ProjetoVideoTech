package modelo;

public class Video {
	private int id;
    private String titulo;
    private String link;
    private double classificacao;
    private Genero genero;
	
	public Video(int id, String titulo, String link, double classificacao, Genero genero) {
        this.id = id;
        this.titulo = titulo;
        this.link = link;
        this.classificacao = classificacao;
        this.genero = genero;
    }
	
	public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public double getClassificacao() {
        return classificacao;
    }

    public void setClassificacao(double classificacao) {
        this.classificacao = classificacao;
    }
   
    
    public Genero getGenero() {
		return genero;
	}

	public void setGenero(Genero genero) {
		this.genero = genero;
	}

	public String toString() {
        return "Video{" +
                "id = " + id + ", titulo = " + titulo + ", link = " + link + ", classificacao = " + classificacao + ", genero = " + genero + '}';
    }
}
