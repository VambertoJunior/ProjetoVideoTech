package modelo;

import java.util.ArrayList;
import java.util.List;

public class Genero {
	private String nome;
	private List<Video> listaDeVideos = new ArrayList<>();
	
	public Genero(String nome) {
		this.nome = nome;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public List<Video> getListaDeVideo(){
		return listaDeVideos;
	}
	
	public void adicionarVideo(Video video) {
        listaDeVideos.add(video);
    }


	public void removerVideo(Video video) {
        listaDeVideos.remove(video);
    }
	
	public void setListaDevideo(List<Video> listaDeVideo) {
		this.listaDeVideos = listaDeVideo;
	}
	
	 @Override
		public String toString() {
			return "Genero [nome=" + nome + ", listaDeVideos=" + listaDeVideos + "]";
		}
}

